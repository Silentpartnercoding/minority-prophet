# HANDOFF — minority-prophet Stages 3–5 build

For: coding agent (Codex). Human reviews all diffs; nothing merges unreviewed.
Target repo: Silentpartnercoding/minority-prophet

## What is in this package

- `STAGE-3-SPEC.md` — full build spec: lineage inference, adversary suite,
  exp003 runner, Lean scaffold, tests, acceptance criteria. Build this FIRST.
- `EXPERIMENT-004-005-ADDENDUM.md` — corruption sweeps, side-confusion
  metrics and control, H5 preregistration, revised Lean targets. Build SECOND.
- `reference/exp003.py, exp004.py, exp004b.py, exp005.py` — working
  stdlib-only replica (~500 lines total). Use as behavioral reference for
  generator/inference/aggregator semantics. Do NOT copy verbatim: repo code
  follows the module layout in STAGE-3-SPEC.md, uses the repo's existing
  aggregation/ and benchmark/ modules, and replaces token-set payloads with
  the repo's claim payload format.
- `results/` — replica outputs (JSON/JSONL, summary tables, three plots).
  These are the qualitative shapes the real build must attempt to replicate.

## Ground rules (repo conventions — do not violate)

1. Python ≥3.10 pinned in pyproject.toml (fixes the zip(strict=True) issue).
2. Every experiment: fixed seeds, environment lock, raw JSONL outputs,
   SHA-256 manifest, EXPERIMENT-00X.md, hypothesis entries BEFORE runs,
   honest verdicts (VALIDATED / PARTIAL / INVALIDATED) in summaries.
3. No network calls in default experiment paths; fully offline-reproducible.
4. No changes to existing aggregation/ public interfaces.
5. Register: no consciousness/general-truth-discovery claims; cite Douceur
   2002 and BFT literature for the erased-signals endpoint.

## Suggested branch/commit sequence

- branch `stage3-lineage`
  1. chore: pin python>=3.10, env lock
  2. feat(lineage): scorers + combiner + eval (tests)
  3. feat(adversary): five attacks + compose (tests)
  4. feat(exp003): runner, metrics, summary, manifest
  5. docs: EXPERIMENT-003.md + hypotheses H3a/H3b
- branch `stage4-sweeps` (after stage3 merges)
  6. feat(metrics): attribution, side-confusion, signed confusion
  7. feat(adversary): side_preserving control
  8. feat(exp004): four sweeps + plots
  9. docs: EXPERIMENT-004/005 + preregister H5 (commit BEFORE H5 run)
  10. results commit: raw JSONL + manifests + verdicts
- branch `formal-scaffold` (parallel, may lag)
  11. feat(formal): Lean defs + majority_not_copyInvariant (no sorry)
  12. feat(formal): immunity-lemma statement (sorry tracked) + CI

## Definition of done for the whole handoff

- All acceptance criteria in both spec files pass.
- Replication verdicts recorded for the four replica findings.
- H5 verdict recorded against its preregistration.
- CI green: pytest/unittest + Lean build (one tracked sorry allowed).

## Known open questions the human decides (do not guess)

- Whether raw market data (Stage 2) hashes get committed alongside these
  synthetic stages, per the provenance-hygiene note.
- Venue/format of the write-up; nothing in this package publishes anything.
