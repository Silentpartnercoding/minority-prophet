"""EXP004 replica: delta-sweep -- map the shape of the provenance threshold.

X-axis: root-set corruption (controlled). Y-axis: truth accuracy of
evidence-root aggregation. Two corruption modes:
  A) composed-attack intensity sweep (attacks corrupt inference naturally)
  B) direct root-set corruption injection (bypass inference; corrupt the
     declared lineage itself) -- separates "inference fails" from
     "aggregation fails given corrupted lineage".
"""
import json, math, random, statistics
from collections import defaultdict
from exp003 import make_world, infer_lineage, roots_of, verdicts

def corrupt_lineage(true_parent, claims, level, rng):
    """Directly rewire a fraction `level` of copy edges to wrong parents
    (uniformly random earlier claim), modelling lineage corruption without
    any inference step."""
    pm = dict(true_parent)
    ids = [c["id"] for c in claims]
    byid = {c["id"]: c for c in claims}
    for cid in list(pm.keys()):
        if rng.random() < level:
            earlier = [i for i in ids if byid[i]["t"] < byid[cid]["t"] and i != cid]
            if earlier:
                pm[cid] = rng.choice(earlier)
            else:
                del pm[cid]  # becomes a fake root
    return pm

def rootset_acc(claims, pm, true_parent):
    tr = set(roots_of(claims, true_parent).values())
    ir = set(roots_of(claims, pm).values())
    return len(tr & ir) / len(tr | ir)

def sweep(worlds=300, seed=7):
    rows = []
    # Mode A: composed attack intensity sweep (inference in the loop)
    for inten in [i/20 for i in range(0, 21)]:
        rng = random.Random(seed)
        accs, rsas = [], []
        for w in range(worlds):
            world = make_world(rng, "composed", inten)
            claims = world["claims"]
            tp = {c["id"]: c["true_parent"] for c in claims if c["true_parent"] is not None}
            inf = infer_lineage(claims)
            rsas.append(rootset_acc(claims, inf, tp))
            vrng = random.Random(seed*1000+w)
            vd, p1 = verdicts(world, inf, vrng)["evidence_root"]
            if vd is not None:
                accs.append(1 if vd == world["T"] else 0)
        rows.append(dict(mode="A_composed", x=inten,
                         rootset=statistics.mean(rsas),
                         acc=statistics.mean(accs) if accs else 0.5,
                         n=len(accs)))
    # Mode B: direct corruption of declared lineage (no inference)
    for level in [i/20 for i in range(0, 21)]:
        rng = random.Random(seed)
        accs, rsas = [], []
        for w in range(worlds):
            world = make_world(rng, "none", 0.0)
            claims = world["claims"]
            tp = {c["id"]: c["true_parent"] for c in claims if c["true_parent"] is not None}
            pm = corrupt_lineage(tp, claims, level, rng)
            rsas.append(rootset_acc(claims, pm, tp))
            vrng = random.Random(seed*1000+w)
            vd, p1 = verdicts(world, pm, vrng)["evidence_root"]
            if vd is not None:
                accs.append(1 if vd == world["T"] else 0)
        rows.append(dict(mode="B_direct", x=level,
                         rootset=statistics.mean(rsas),
                         acc=statistics.mean(accs) if accs else 0.5,
                         n=len(accs)))
    return rows

if __name__ == "__main__":
    rows = sweep()
    with open("/home/claude/exp004_sweep.json", "w") as f:
        json.dump(rows, f, indent=1)
    for r in rows:
        print(f"{r['mode']:11s} x={r['x']:.2f} rootset={r['rootset']:.3f} acc={r['acc']:.3f}")
