"""EXP005 replica -- THE FINAL STUDY: is cross-side root confusion the true axis?

Hypothesis (from EXP004): accuracy is determined by side-confusion --
the fraction of claims attributed to a root whose own assertion differs
from the claim's assertion -- NOT by attack intensity or attribution error.

Test: three corruption modes plotted on the same side-confusion axis.
  A) composed adversarial attack (inference in the loop)
  B) direct random lineage corruption (side-blind rewiring)
  C) side-preserving corruption (rewire edges ONLY within same-assertion
     claims) -- the critical control: attribution gets badly corrupted but
     side-confusion stays ~0. If the hypothesis is right, accuracy stays
     HIGH here no matter how hard we corrupt.
If A, B collapse onto one curve and C stays flat at high accuracy,
side-confusion is the theorem's x-axis.
"""
import json, random, statistics
from exp003 import make_world, infer_lineage, roots_of, verdicts
from exp004 import corrupt_lineage

def corrupt_side_preserving(tp, claims, level, rng):
    """Rewire fraction `level` of edges, but new parent must share the
    child's assertion (side-preserving)."""
    pm = dict(tp)
    byid = {c["id"]: c for c in claims}
    for cid in list(pm.keys()):
        if rng.random() < level:
            c = byid[cid]
            cand = [p["id"] for p in claims
                    if p["t"] < c["t"] and p["id"] != cid
                    and p["assertion"] == c["assertion"]]
            if cand:
                pm[cid] = rng.choice(cand)
            else:
                del pm[cid]
    return pm

def side_confusion(claims, pm):
    byid = {c["id"]: c for c in claims}
    rmap = roots_of(claims, pm)
    return sum(1 for c in claims
               if byid[rmap[c["id"]]]["assertion"] != c["assertion"]) / len(claims)

def attribution_acc(claims, pm, tp):
    tr, gr = roots_of(claims, tp), roots_of(claims, pm)
    return sum(1 for c in claims if tr[c["id"]] == gr[c["id"]]) / len(claims)

def run(worlds=300, seed=7):
    rows = []
    for mode in ["A", "B", "C"]:
        for i in range(0, 21):
            x = i / 20
            rng = random.Random(seed)
            accs, confs, atts = [], [], []
            for w in range(worlds):
                if mode == "A":
                    world = make_world(rng, "composed", x)
                    claims = world["claims"]
                    tp = {c["id"]: c["true_parent"] for c in claims if c["true_parent"] is not None}
                    pm = infer_lineage(claims)
                else:
                    world = make_world(rng, "none", 0.0)
                    claims = world["claims"]
                    tp = {c["id"]: c["true_parent"] for c in claims if c["true_parent"] is not None}
                    pm = (corrupt_lineage(tp, claims, x, rng) if mode == "B"
                          else corrupt_side_preserving(tp, claims, x, rng))
                confs.append(side_confusion(claims, pm))
                atts.append(attribution_acc(claims, pm, tp))
                vrng = random.Random(seed * 1000 + w)
                vd, _ = verdicts(world, pm, vrng)["evidence_root"]
                if vd is not None:
                    accs.append(1 if vd == world["T"] else 0)
            rows.append(dict(mode=mode, x=x,
                             side_confusion=statistics.mean(confs),
                             attribution=statistics.mean(atts),
                             acc=statistics.mean(accs) if accs else 0.5))
            r = rows[-1]
            print(f"{mode} x={x:.2f} conf={r['side_confusion']:.3f} "
                  f"attr={r['attribution']:.3f} acc={r['acc']:.3f}")
    json.dump(rows, open("/home/claude/exp005.json", "w"), indent=1)
    return rows

if __name__ == "__main__":
    run()
