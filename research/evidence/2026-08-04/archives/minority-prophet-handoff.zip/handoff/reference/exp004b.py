"""Re-sweep with the correct x-axis: root ATTRIBUTION accuracy
(fraction of claims mapped to their true root), then plot acc vs attribution."""
import json, random, statistics
from exp003 import make_world, infer_lineage, roots_of, verdicts
from exp004 import corrupt_lineage

def attribution_acc(claims, pm, tp):
    true_r = roots_of(claims, tp)
    got_r = roots_of(claims, pm)
    return sum(1 for c in claims if true_r[c["id"]] == got_r[c["id"]]) / len(claims)

def run(worlds=300, seed=7):
    rows = []
    for mode in ["A", "B"]:
        for i in range(0, 21):
            x = i / 20
            rng = random.Random(seed)
            accs, atts = [], []
            for w in range(worlds):
                if mode == "A":
                    world = make_world(rng, "composed", x)
                    claims = world["claims"]
                    tp = {c["id"]: c["true_parent"] for c in claims if c["true_parent"] is not None}
                    pm = infer_lineage(claims)
                else:
                    world = make_world(rng, "none", 0.0)
                    claims = world["claims"]
                    tp = {c["id"]: c["true_parent"] for c in claims if c["true_parent"] is not None}
                    pm = corrupt_lineage(tp, claims, x, rng)
                atts.append(attribution_acc(claims, pm, tp))
                vrng = random.Random(seed * 1000 + w)
                vd, p1 = verdicts(world, pm, vrng)["evidence_root"]
                if vd is not None:
                    accs.append(1 if vd == world["T"] else 0)
            rows.append(dict(mode=mode, x=x, attribution=statistics.mean(atts),
                             acc=statistics.mean(accs) if accs else 0.5))
            print(f"{mode} x={x:.2f} attribution={statistics.mean(atts):.3f} acc={statistics.mean(accs):.3f}")
    json.dump(rows, open("/home/claude/exp004b.json", "w"))
    return rows

if __name__ == "__main__":
    run()
