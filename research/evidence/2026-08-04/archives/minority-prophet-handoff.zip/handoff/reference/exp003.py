"""EXP003 replica: inferred lineage + adversarial copying (stdlib only).

Self-contained reimplementation of the Stage 3 spec for minority-prophet.
Not the canonical repo code -- an indicative pressure test of the design.
"""
import json, math, random, hashlib, statistics, sys
from collections import defaultdict

VOCAB = 5000
SYN_OFFSET = 100000  # synonym map unknown to similarity scorer

# ---------------- world generation ----------------

def make_world(rng, adversary, intensity):
    """Return dict with claims + ground truth + true parent map."""
    T = rng.randint(0, 1)                      # hidden truth
    copy_pressure = rng.random() < 0.6         # 60% copied-majority-false worlds
    false_claim = 1 - T
    orig_assert = false_claim if copy_pressure else T

    claims = []  # each: id, agent, t, assertion, tokens, cite, true_parent, kind
    def payload():
        return set(rng.sample(range(VOCAB), 12))

    # prestigious originator
    t0 = 10.0
    if adversary == "timing" or (adversary == "composed" and intensity > 0):
        t0 = 0.5  # front-run honest observers
    claims.append(dict(id=0, agent="orig", t=t0, assertion=orig_assert,
                       tokens=payload(), cite=None, true_parent=None, kind="root"))

    # independent observers (reliability .9), each its own evidence root
    n_obs = 6
    for i in range(n_obs):
        a = T if rng.random() < 0.9 else 1 - T
        claims.append(dict(id=len(claims), agent=f"obs{i}", t=1.0 + rng.random() * 8,
                           assertion=a, tokens=payload(), cite=None,
                           true_parent=None, kind="root"))

    # copiers: preferential attachment to originator's copy tree
    n_cop = 40
    para = intensity if adversary in ("paraphrase", "composed") else 0.0
    fcite = intensity if adversary in ("false_citation", "composed") else 0.0
    syb = intensity if adversary in ("sybil", "composed") else 0.0
    tree = [0]
    for i in range(n_cop):
        parent = claims[rng.choice(tree)]
        toks = set(parent["tokens"])
        for _ in range(2):  # natural mutation
            if toks:
                toks.discard(rng.choice(sorted(toks)))
                toks.add(rng.randrange(VOCAB))
        is_sybil = rng.random() < syb
        p_rate = 0.8 if is_sybil else para
        toks = {t + SYN_OFFSET if rng.random() < p_rate else t for t in toks}
        cite = parent["id"]
        if is_sybil:
            cite = None
        elif rng.random() < fcite:
            cite = rng.randrange(1, 1 + n_obs)  # forged: point at an observer
        t = (t0 + 0.2 + rng.random() * 3) if is_sybil else parent["t"] + 0.5 + rng.random() * 5
        c = dict(id=len(claims), agent=f"cop{i}", t=t, assertion=parent["assertion"],
                 tokens=toks, cite=cite, true_parent=parent["id"], kind="copy")
        claims.append(c)
        tree.append(c["id"])
    return dict(T=T, copy_pressure=copy_pressure, claims=claims)

# ---------------- lineage ----------------

def jaccard(a, b):
    u = len(a | b)
    return len(a & b) / u if u else 0.0

def infer_lineage(claims, thresh=0.25):
    by_t = sorted(claims, key=lambda c: c["t"])
    parent = {}
    for i, c in enumerate(by_t):
        best, best_s = None, thresh
        for p in by_t[:i]:
            if p["t"] >= c["t"]:
                continue
            s = (0.45 * jaccard(c["tokens"], p["tokens"])
                 + 0.25 * math.exp(-(c["t"] - p["t"]) / 5.0)
                 + 0.30 * (1.0 if c["cite"] == p["id"] else 0.0))
            if s > best_s:
                best, best_s = p["id"], s
        if best is not None:
            parent[c["id"]] = best
    return parent  # child -> parent

def roots_of(claims, parent):
    memo = {}
    def root(cid):
        if cid in memo:
            return memo[cid]
        r = cid if cid not in parent else root(parent[cid])
        memo[cid] = r
        return r
    return {c["id"]: root(c["id"]) for c in claims}

# ---------------- aggregators ----------------

def verdicts(world, parent_map, rng):
    claims = world["claims"]
    out = {}
    # majority
    v = [c["assertion"] for c in claims]
    p1 = sum(v) / len(v)
    out["majority"] = decide(p1)
    # competence-weighted (noisy estimates; herding inflates copier estimates)
    w1 = w0 = 0.0
    for c in claims:
        rel = 0.9 if c["kind"] == "root" and c["agent"] != "orig" else 0.6
        est = min(0.99, max(0.01, rel + rng.gauss(0, 0.15)))
        w = math.log(est / (1 - est))
        if c["assertion"] == 1: w1 += w
        else: w0 += w
    out["competence"] = decide(w1 / (w1 + w0) if (w1 + w0) > 0 else 0.5)
    # evidence-root
    rmap = roots_of(claims, parent_map)
    side = defaultdict(set)
    for c in claims:
        side[c["assertion"]].add(rmap[c["id"]])
    r1, r0 = len(side[1]), len(side[0])
    out["evidence_root"] = decide(r1 / (r1 + r0) if (r1 + r0) else 0.5)
    return out

def decide(p1, margin=0.02):
    if abs(p1 - 0.5) < margin:
        return (None, p1)          # abstain
    return ((1 if p1 > 0.5 else 0), p1)

# ---------------- experiment ----------------

def run(worlds=200, seed=7):
    adversaries = [("none", 0.0), ("paraphrase", 0.5), ("false_citation", 0.5),
                   ("sybil", 0.5), ("timing", 1.0), ("composed", 0.5)]
    lineages = ["declared", "inferred", "none"]
    aggs = ["majority", "competence", "evidence_root"]
    results = defaultdict(lambda: defaultdict(list))
    lin_scores = defaultdict(list)
    raw = []
    for adv, inten in adversaries:
        rng = random.Random(seed)
        for w in range(worlds):
            world = make_world(rng, adv, inten)
            claims = world["claims"]
            true_parent = {c["id"]: c["true_parent"] for c in claims
                           if c["true_parent"] is not None}
            inferred = infer_lineage(claims)
            # lineage quality
            tp = sum(1 for k, v in inferred.items() if true_parent.get(k) == v)
            prec = tp / len(inferred) if inferred else 1.0
            rec = tp / len(true_parent) if true_parent else 1.0
            f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
            true_roots = set(roots_of(claims, true_parent).values())
            inf_roots = set(roots_of(claims, inferred).values())
            rootacc = len(true_roots & inf_roots) / len(true_roots | inf_roots)
            lin_scores[adv].append((prec, rec, f1, rootacc))
            for lin in lineages:
                pm = true_parent if lin == "declared" else inferred if lin == "inferred" else {}
                vrng = random.Random(seed * 1000 + w)
                for agg, (vd, p1) in verdicts(world, pm, vrng).items():
                    if lin != "none" or agg != "evidence_root":
                        pass
                    rec_row = dict(adv=adv, lin=lin, agg=agg, world=w,
                                   T=world["T"], cp=world["copy_pressure"],
                                   verdict=vd, p1=round(p1, 4))
                    raw.append(rec_row)
                    results[(adv, lin)][agg].append(rec_row)
    return results, lin_scores, raw

def summarize(results, lin_scores):
    lines = ["# EXP003 replica -- summary", "",
             "| adversary | lineage | aggregator | acc | minority-recovery | brier | abstain |",
             "|---|---|---|---|---|---|---|"]
    table = {}
    for (adv, lin), aggs in sorted(results.items()):
        for agg, rows in aggs.items():
            dec = [r for r in rows if r["verdict"] is not None]
            acc = sum(1 for r in dec if r["verdict"] == r["T"]) / len(dec) if dec else 0
            cp = [r for r in dec if r["cp"]]
            mrec = sum(1 for r in cp if r["verdict"] == r["T"]) / len(cp) if cp else 0
            brier = statistics.mean((r["p1"] - r["T"]) ** 2 for r in rows)
            abst = sum(1 for r in rows if r["verdict"] is None) / len(rows)
            lines.append(f"| {adv} | {lin} | {agg} | {acc:.3f} | {mrec:.3f} | {brier:.3f} | {abst:.3f} |")
            table[(adv, lin, agg)] = (acc, mrec, brier, abst)
    lines += ["", "## Lineage inference quality", "",
              "| adversary | precision | recall | F1 | root-set acc |", "|---|---|---|---|---|"]
    for adv, scores in lin_scores.items():
        p, r, f, ra = (statistics.mean(x[i] for x in scores) for i in range(4))
        lines.append(f"| {adv} | {p:.3f} | {r:.3f} | {f:.3f} | {ra:.3f} |")
    return "\n".join(lines), table

if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    results, lin_scores, raw = run(worlds=n, seed=7)
    md, table = summarize(results, lin_scores)
    with open("/home/claude/summary.md", "w") as f:
        f.write(md + "\n")
    blob = json.dumps(raw, sort_keys=True).encode()
    with open("/home/claude/raw.jsonl", "w") as f:
        for r in raw:
            f.write(json.dumps(r) + "\n")
    print(md)
    print("\nsha256(raw):", hashlib.sha256(blob).hexdigest()[:16], "worlds:", n)
