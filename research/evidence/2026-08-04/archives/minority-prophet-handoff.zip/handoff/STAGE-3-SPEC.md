# STAGE 3 BUILD SPEC — Inferred Lineage + Adversarial Copying + Lean Scaffold

Target repo: `Silentpartnercoding/minority-prophet`
Experiment ID: `EXPERIMENT-003`
Builder: coding agent (Codex). Human reviews all diffs before merge.

## North star for this stage

Stages 1–2 assumed lineage was *declared* (synthetic) or side-stepped it (market data).
Stage 3 attacks the program's known weak point: **can lineage be inferred from
observable signals, and does inferred lineage still let evidence-root aggregation
recover minority truth — including against an active adversary?**

Everything below serves that one question. Do not add features beyond this scope.

---

## 1. New module: `lineage/` (lineage inference)

Infer a directed acyclic evidence graph from observables only. No access to the
generator's true DAG at inference time.

**Inputs per claim:** claim id, agent id, timestamp, claim text/payload,
confidence, (optional) cited-source field that may be missing or false.

**Required inference signals (implement each as a separate, composable scorer):**
- `temporal.py` — candidate parent must precede child; score by time proximity.
- `similarity.py` — payload similarity (start with token/Jaccard + difflib ratio;
  keep the interface pluggable so an embedding scorer can be added later without
  touching callers).
- `citation.py` — declared citations, treated as *evidence for* an edge, never
  as ground truth (citations can be forged; see adversary spec).
- `combine.py` — weighted combination → edge probabilities → DAG construction.
  Enforce acyclicity by timestamp ordering. Threshold is a config parameter.

**Output:** `InferredGraph` in the same schema as `provenance/` declared graphs,
plus per-edge confidence, serialized to JSON matching the existing JSON Schema
(extend schema with `edge_confidence` and `inferred: true` fields; keep
backward compatibility).

**Evaluation:** `lineage/eval.py` — precision, recall, F1 of inferred edges vs
true edges; ancestor-set accuracy (does the inferred root set match the true
root set per proposition?). Root-set accuracy is the metric that matters most;
report both.

## 2. New module: `adversary/` (attack generators)

Extend the synthetic world generator with attacker strategies. Each attack is a
world transformation with a single intensity parameter in [0, 1], fixed seeds.

- `paraphrase.py` — copied claims are rewritten (synonym/word-order/structure
  perturbations, deterministic under seed) to defeat similarity scoring while
  preserving meaning. Include a paraphrase-strength knob.
- `false_citation.py` — copied claims cite a fabricated or independent-looking
  source instead of their true parent.
- `sybil.py` — one attacker controls k identities that each "independently"
  assert the false claim with staggered timestamps and paraphrased payloads.
- `timing.py` — attacker posts the false claim *before* honest observations
  land (front-running), breaking the earliest-is-root heuristic.
- `compose.py` — combine attacks; the flagship condition is
  paraphrase + false_citation + sybil at matched intensities.

## 3. Experiment runner: `experiments/exp003_inferred_lineage.py`

Grid, all with `--worlds 500 --seed 7` defaults (CLI-overridable):

- Lineage condition: {declared (oracle), inferred, none}
- Adversary: {none, each single attack at 0.25/0.5/0.75, composed at 0.5}
- Aggregator: {simple majority, competence-weighted, evidence-root, semantic}
  — reuse existing implementations in `aggregation/`; do not modify them.

**Metrics per cell (reuse `benchmark/` metrics, add lineage metrics):**
truth accuracy, minority-truth recovery, Brier score, abstention rate,
lineage F1, root-set accuracy, wall-clock per world.

**Outputs:**
- `results/exp003/raw/*.jsonl` — one record per world (append-only, hashed)
- `results/exp003/summary.md` — auto-generated table + the three headline plots:
  (a) truth accuracy vs adversary intensity per lineage condition,
  (b) lineage F1 vs adversary intensity,
  (c) minority-truth recovery: declared vs inferred vs none.
- SHA-256 manifest of raw outputs, matching the existing preservation convention.

## 4. Docs (required, same templates as EXPERIMENT-001)

- `experiments/EXPERIMENT-003.md` — design, controls, seeds, environment lock.
- New entry in `RESEARCH-HYPOTHESES.md` using the required template:
  - H3a — Question: does inferred lineage recover enough of the true root set
    to preserve minority-truth recovery? Null: evidence-root aggregation with
    inferred lineage performs no better than majority voting. Metric:
    minority-truth recovery at ρ ≥ 5. Failure: recovery within 5 points of
    majority baseline under no-adversary condition. Success: ≥ 80% of the
    declared-lineage recovery rate under no-adversary condition.
  - H3b — Question: which attack degrades inferred-lineage aggregation most
    per unit intensity? Null: all attacks degrade equally. Metric: slope of
    truth accuracy vs intensity. Failure/success per template.
- Verdict line (VALIDATED / PARTIAL / INVALIDATED) in `results/exp003/summary.md`.

## 5. Lean scaffold: `formal/` (parallel track — must not block 1–4)

Lean 4 + mathlib project, built in CI but marked experimental.

- `lakefile.lean`, toolchain pin.
- `Formal/Defs.lean` — finite model: `Agent`, `Claim`, `EvidenceGraph`
  (finite DAG over claims), `rootSet`, `Aggregator := EvidenceGraph → Verdict`.
  Mirror FOUNDATIONS.md definitions; where FOUNDATIONS.md is ambiguous, add a
  `-- DECISION:` comment stating the interpretation chosen, so the human can
  review each one.
- `Formal/CopyInvariance.lean` —
  - `def copyInvariant (F : Aggregator) : Prop` — duplicating a claim without
    adding a new root does not change the verdict.
  - `theorem majority_not_copyInvariant` — full proof by explicit finite
    counterexample world. This must compile with no `sorry`.
  - `theorem rootCount_copyInvariant` — statement now; `sorry` allowed,
    tracked in `formal/TODO.md`.
- `.github/workflows/lean.yml` — build proofs on push; the `sorry` in the
  positive theorem is allowed, but `majority_not_copyInvariant` failing to
  compile fails CI.

## 6. Tests

- `tests/test_lineage_*.py` — each scorer; combined inference on a hand-built
  5-claim world with known DAG; acyclicity guaranteed; schema round-trip.
- `tests/test_adversary_*.py` — determinism under seed; intensity 0 is a no-op;
  paraphrase preserves proposition label.
- `tests/test_exp003_smoke.py` — full runner on `--worlds 5`, asserts all
  output files and manifest hashes are produced.
- All existing tests must still pass unmodified.

## 7. Acceptance criteria (definition of done)

1. `python -m experiments.exp003_inferred_lineage --worlds 5 --seed 7` runs
   end-to-end on a clean checkout with only `pyproject.toml` dependencies.
2. Full grid at 500 worlds completes; summary.md and plots are generated.
3. Lineage F1 and root-set accuracy reported for every adversary condition.
4. `unittest discover` green; Lean CI green with exactly one tracked `sorry`.
5. EXPERIMENT-003.md, hypothesis entries, verdict, and hash manifest present.
6. No changes to `aggregation/` public interfaces; schema changes are
   backward compatible.

## Non-goals for this stage

- No embedding models or network calls in the default path (keep the benchmark
  reproducible offline; embedding scorer lands behind a flag later).
- No real-world (market) data — that's Stage 2's dataset and a separate write-up.
- No dashboard/UI work beyond wiring exp003 summaries into the existing site nav.
- No claims about consciousness, general truth discovery, or literal ultraproducts
  anywhere in docs. Match the existing epistemic-hygiene register.
