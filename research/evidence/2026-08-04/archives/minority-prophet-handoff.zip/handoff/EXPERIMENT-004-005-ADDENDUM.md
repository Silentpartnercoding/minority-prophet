# ADDENDUM — EXP004 (threshold shape) + EXP005 (side-confusion test)

Extends STAGE-3-SPEC.md. Reference implementations and replica results are in
`reference/` and `results/`. These are DESIGN-VALIDATION numbers from a
simplified sandbox replica — the canonical runs must be rebuilt in-repo with
the real world generator, then compared against the replica's qualitative
findings (shapes, not exact values).

## Replica findings to test for replication

1. RAMP, NOT CLIFF — under random lineage corruption, accuracy degrades
   smoothly (~linearly) with corruption level. No sharp phase transition.
2. ADVERSARIAL VALLEY — under the composed attack, accuracy vs intensity is
   non-monotonic: worst near intensity 0.4–0.7, recovering at max intensity
   because uniform sybil disguise makes sybils mutually similar and they
   re-cluster into one family. CAUTION: the replica's deterministic synonym
   map likely exaggerates this; test with stochastic paraphrase before
   believing it.
3. SIDE-CONFUSION CONTROL — corruption that rewires lineage only within
   same-assertion claims (side-preserving) destroyed attribution accuracy
   (1.0 → 0.59) with NO accuracy loss (≥0.98 throughout). Zero cross-side
   confusion => immunity, regardless of corruption level.
4. ASYMMETRY GAP (unproven, next hypothesis) — at matched total
   side-confusion, adversarial corruption (mode A) hurts far more than random
   corruption (mode B). Likely mechanism: adversarial misattribution is
   DIRECTIONAL (systematically credits one side with the other side's roots),
   while random confusion is symmetric and partially self-cancelling.

## H5 (new, preregister before running)

Question: is SIGNED side-confusion (net phantom-root gain to the false side)
the sufficient statistic for accuracy, collapsing all corruption modes onto
one curve?
Metric: accuracy vs signed confusion = (phantom roots gained by false side −
phantom roots gained by true side) / total roots, computed per world.
Null: curves for modes A, B, C and per-attack sweeps do NOT collapse
(residual mode effect after conditioning on signed confusion).
Success: residual mode effect within noise band across all modes.
Failure: any mode deviates beyond the band => the sufficient statistic is
richer than a scalar; report what residual structure predicts the deviation.

## Build tasks (delta on STAGE-3-SPEC.md)

- `experiments/exp004_sweep.py` — corruption sweeps: composed-intensity,
  direct-random, side-preserving, plus per-attack sweeps at matched
  side-confusion. 21 points × ≥300 worlds, fixed seeds.
- `lineage/metrics.py` — add: attribution accuracy, side-confusion, signed
  side-confusion. Root-SET overlap is retained but demoted (EXP004 showed it
  is blind to attribution damage).
- `adversary/side_preserving.py` — the mode-C control transformation.
- Plots: acc-vs-intensity (all modes), acc-vs-side-confusion scatter,
  acc-vs-signed-confusion (H5's figure).
- Docs: EXPERIMENT-004.md and EXPERIMENT-005.md per template; H5 entry in
  RESEARCH-HYPOTHESES.md BEFORE the H5 run; verdicts in summaries.

## Formal target (updates formal/ plan)

The Lean goal shifts from a corruption-threshold theorem to:
  (i)  Immunity lemma: zero cross-side confusion => evidence-root verdict
       equals the declared-lineage verdict. (Mode C is the empirical shadow;
       this should be provable and is the new first positive target after
       majority_not_copyInvariant.)
  (ii) Degradation bound: verdict margin as a function of signed confusion.
Positioning note for the eventual write-up: the all-signals-erased endpoint is
KNOWN territory (Douceur 2002 sybil impossibility; BFT bounds) — cite it,
don't reprove it. The contribution is the middle: shape of degradation and
the minimal sufficient guarantee (side-separation, not full lineage).

## Acceptance criteria

1. All four sweeps run from one CLI entrypoint with seeds; JSONL + hash
   manifest per sweep.
2. Replication verdict recorded for findings 1–3 (REPLICATED / PARTIAL /
   NOT REPLICATED) and finding 2 re-tested under stochastic paraphrase.
3. H5 preregistered before its run; verdict against preregistration.
4. Immunity lemma stated in Lean; `sorry` allowed initially, tracked.
