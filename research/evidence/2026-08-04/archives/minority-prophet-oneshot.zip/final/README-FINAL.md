# ONE-SHOT COMPLETION -- proof, experiments, product

STEP 1 -- PROOF (formal/)
- PROOFS.md: Theorems 1-4 with full paper proofs. T1 Immunity: verdicts are
  invariant under side-preserving, root-preserving lineage corruption.
  T2 copy invariance. T3 majority counterexample. T4 margin flip condition
  (promoted from H5's rejection).
- verify_proofs.py: machine-led inspection PASSED -- exhaustive over 5,912
  worlds / 121,944 rewirings (all worlds n<=6), 100,000 randomized larger
  instances, ZERO violations. Rerun anytime: python3 formal/verify_proofs.py
- MinorityProphet.lean: Lean 4 statements (T3 fully proved; T1/Lemma 1
  sorry-stubbed to paper proofs) for in-repo CI compilation.

STEP 2 -- EXPERIMENTS (results/)
- exp006_h5.py/.json/.png: H5 preregistered verdict = REJECTED. Signed
  side-confusion does NOT collapse corruption modes (max spread 0.651).
  The correct law is per-world and margin-relative -> Theorem 4. Lineage
  purity is not the defense; ROOT MARGIN is the attack budget.
- Earlier replicas (exp003-005) in the stage-3 handoff package.

STEP 3 -- PRODUCT (product/)
- minority_prophet.py: stdlib-only reference library. Claim / EvidenceGraph /
  aggregate(). Cycle + orphan detection, optional stake weights, abstention
  margin, diagnostics incl. immunity_applicable and flip_budget (T4).
- test_minority_prophet.py: 8/8 PASS incl. 500-world randomized immunity test.
- conformance_vectors.json: 6 spec-derived vectors any future port must pass.

Chain of custody: proofs verified -> library implements proved spec ->
conformance vectors carry the spec to ports. Sandbox caveats: Lean not
compiled here (no network; CI job in HANDOFF.md does it); replica generator,
not repo generator. MANIFEST hashes below cover every file in this package.
