"""EXP006 -- H5 as preregistered: does SIGNED side-confusion collapse all
corruption modes onto one curve?
signed s = (|{T-asserting roots credited to side ~T}| -
            |{~T-asserting roots credited to side T}|) / |roots|
Positive s inflates the false side. Prediction: acc is a single decreasing
function of s across modes A (adversarial), B (random), C (side-preserving)."""
import json, random, statistics, sys
sys.path.insert(0, "/home/claude")
from exp003 import make_world, infer_lineage, roots_of, verdicts
from exp004 import corrupt_lineage
from exp005 import corrupt_side_preserving

def signed_conf(claims, pm, T):
    byid = {c["id"]: c for c in claims}
    rmap = roots_of(claims, pm)
    sides = {0: set(), 1: set()}
    for c in claims:
        sides[c["assertion"]].add(rmap[c["id"]])
    allroots = set(rmap.values())
    # roots whose own assertion is a, credited to side 1-a
    toFalse = sum(1 for r in sides[1 - T] if byid[r]["assertion"] == T)
    toTrue  = sum(1 for r in sides[T] if byid[r]["assertion"] == 1 - T)
    return (toFalse - toTrue) / max(1, len(allroots))

def run(worlds=300, seed=7):
    rows = []
    for mode in ["A", "B", "C"]:
        for i in range(21):
            x = i / 20
            rng = random.Random(seed)
            per = []
            for w in range(worlds):
                if mode == "A":
                    world = make_world(rng, "composed", x)
                    claims = world["claims"]
                    pm = infer_lineage(claims)
                else:
                    world = make_world(rng, "none", 0.0)
                    claims = world["claims"]
                    tp = {c["id"]: c["true_parent"] for c in claims
                          if c["true_parent"] is not None}
                    pm = (corrupt_lineage(tp, claims, x, rng) if mode == "B"
                          else corrupt_side_preserving(tp, claims, x, rng))
                s = signed_conf(claims, pm, world["T"])
                vd, _ = verdicts(world, pm, random.Random(seed*1000+w))["evidence_root"]
                per.append((s, None if vd is None else int(vd == world["T"])))
            dec = [p for p in per if p[1] is not None]
            rows.append(dict(mode=mode, x=x,
                             signed=statistics.mean(p[0] for p in per),
                             acc=statistics.mean(p[1] for p in dec) if dec else 0.5,
                             pts=[(round(p[0],3), p[1]) for p in per]))
            r = rows[-1]
            print(f"{mode} x={x:.2f} signed={r['signed']:+.3f} acc={r['acc']:.3f}")
    json.dump([{k: v for k, v in r.items() if k != "pts"} for r in rows],
              open("/home/claude/final/results/exp006_h5.json", "w"), indent=1)
    # H5 verdict: bin per-world points by signed conf across modes; compare
    binned = {}
    for r in rows:
        for s, ok in r["pts"]:
            if ok is None: continue
            b = round(s * 10) / 10
            binned.setdefault(b, {}).setdefault(r["mode"], []).append(ok)
    print("\nbin  |   A     B     C   (acc; n)")
    spread = []
    for b in sorted(binned):
        cell = binned[b]
        vals = {m: statistics.mean(v) for m, v in cell.items() if len(v) >= 30}
        if len(vals) >= 2:
            spread.append(max(vals.values()) - min(vals.values()))
        line = "  ".join(f"{m}:{statistics.mean(v):.2f}({len(v)})"
                          for m, v in sorted(cell.items()))
        print(f"{b:+.1f} | {line}")
    if spread:
        print(f"\nmax cross-mode accuracy spread in shared bins: {max(spread):.3f}")
        print("H5 VERDICT:", "SUPPORTED (collapse within 0.10)" if max(spread) <= 0.10
              else f"REJECTED (residual mode effect {max(spread):.3f} > 0.10)")
    else:
        print("H5 VERDICT: INCONCLUSIVE (no shared bins with n>=30)")

if __name__ == "__main__":
    run()
