"""EXP007 -- the finisher: (a) multi-seed replication with CIs of the three
headline findings; (b) OPTIMIZING adversary searching attack space for the
cheapest accuracy kill. T4 prediction: flipped worlds are the thin-margin
worlds; the optimizer converges toward mixed/heterogeneous intensity."""
import random, statistics, math, sys, json
sys.path.insert(0, "/home/claude")
from exp003 import make_world, infer_lineage, roots_of, verdicts
from exp005 import corrupt_side_preserving

def acc_condition(mode, x, seed, worlds=150):
    rng = random.Random(seed)
    accs, margins_flip, margins_ok = [], [], []
    for w in range(worlds):
        if mode == "composed":
            world = make_world(rng, "composed", x); claims = world["claims"]
            pm = infer_lineage(claims)
        elif mode == "sidepreserve":
            world = make_world(rng, "none", 0.0); claims = world["claims"]
            tp = {c["id"]: c["true_parent"] for c in claims if c["true_parent"] is not None}
            pm = corrupt_side_preserving(tp, claims, x, rng)
        else:  # declared
            world = make_world(rng, "none", 0.0); claims = world["claims"]
            pm = {c["id"]: c["true_parent"] for c in claims if c["true_parent"] is not None}
        # true margin under declared lineage
        tp = {c["id"]: c["true_parent"] for c in claims if c["true_parent"] is not None}
        rm = roots_of(claims, tp); sides = {0: set(), 1: set()}
        byid = {c["id"]: c for c in claims}
        for c in claims: sides[c["assertion"]].add(rm[c["id"]])
        margin = abs(len(sides[1]) - len(sides[0]))
        vd, _ = verdicts(world, pm, random.Random(seed * 999 + w))["evidence_root"]
        ok = (vd == world["T"]) if vd is not None else None
        if ok is not None:
            accs.append(int(ok))
            (margins_ok if ok else margins_flip).append(margin)
    return (statistics.mean(accs), margins_ok, margins_flip)

def ci(vals):
    m = statistics.mean(vals); s = statistics.stdev(vals) if len(vals) > 1 else 0
    h = 1.96 * s / math.sqrt(len(vals))
    return m, m - h, m + h

print("== (a) MULTI-SEED REPLICATION, 10 seeds x 150 worlds ==")
seeds = list(range(1, 11)); rep = {}
for name, mode, x in [("baseline_declared", "declared", 0.0),
                      ("immunity_C_x1.0", "sidepreserve", 1.0),
                      ("valley_composed_x0.5", "composed", 0.5),
                      ("recovery_composed_x1.0", "composed", 1.0)]:
    vals = [acc_condition(mode, x, s)[0] for s in seeds]
    m, lo, hi = ci(vals)
    rep[name] = (m, lo, hi)
    print(f"{name:26s} acc={m:.3f}  95%CI [{lo:.3f},{hi:.3f}]")
imm_holds = rep["immunity_C_x1.0"][1] > 0.95
valley = rep["valley_composed_x0.5"][2] < rep["recovery_composed_x1.0"][1]
print(f"-> immunity survives seeds: {imm_holds}; valley<recovery non-overlapping: {valley}")

print("\n== (b) OPTIMIZING ADVERSARY (random-restart hill climb, budget 45 evals) ==")
def attack_acc(params, seed=101, worlds=80):
    para, fcite, syb = params
    rng = random.Random(seed); accs = []; flip_m = []; ok_m = []
    for w in range(worlds):
        world = make_world(rng, "composed", 0.0)  # base; apply custom mix
        # rebuild with custom intensities by regenerating:
        pass
    # simpler: reuse generator's composed path by monkey-param sweep
    return None
# Direct approach: extend generator call by temporarily setting adversary mix
import exp003 as E
def custom_world(rng, para, fcite, syb, timing):
    adv = "composed"  # composed reads one intensity; emulate mix via avg? No--
    return None
# Cleanest: inline a custom composed generator mirroring exp003.make_world
def make_world_mix(rng, para, fcite, syb, timing):
    w = E.make_world.__wrapped__ if hasattr(E.make_world, "__wrapped__") else None
    return None
