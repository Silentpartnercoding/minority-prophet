/- Minority Prophet: formal core. Lean 4 + mathlib.
   States Lemma 1 (side-locality), Theorem 1 (immunity), Theorem 2 (copy
   invariance), Theorem 3 (majority counterexample). Proofs of 1,2 follow the
   paper proofs in PROOFS.md; compile in-repo CI (cannot compile in this
   sandbox: no network for toolchain). -/
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic

structure World (n : ℕ) where
  parent : Fin n → Option (Fin n)
  assert : Fin n → Bool
  acyclic : ∀ i j, parent i = some j → j < i   -- time order

def sideConsistent {n} (W : World n) : Prop :=
  ∀ i j, W.parent i = some j → W.assert j = W.assert i

def root {n} (W : World n) : Fin n → Fin n
  | i => match h : W.parent i with
    | none => i
    | some j => root W j
  termination_by i => i.val
  decreasing_by exact W.acyclic _ _ h

def sideRoots {n} (W : World n) (a : Bool) : Finset (Fin n) :=
  (Finset.univ.filter (fun i => W.assert i = a)).image (root W)

inductive Verdict | one | zero | abstain deriving DecidableEq

def F {n} (W : World n) : Verdict :=
  let s1 := (sideRoots W true).card
  let s0 := (sideRoots W false).card
  if s1 > s0 then .one else if s0 > s1 then .zero else .abstain

/-- Lemma 1: under side-consistency, sideRoots a = roots asserting a. -/
theorem side_locality {n} (W : World n) (hs : sideConsistent W) (a : Bool) :
    sideRoots W a =
      Finset.univ.filter (fun r => W.parent r = none ∧ W.assert r = a) := by
  sorry -- induction on chain length via `root`; see PROOFS.md Lemma 1

/-- Theorem 1 (Immunity): side-preserving, root-preserving rewiring fixes F. -/
theorem immunity {n} (W W' : World n)
    (hW : sideConsistent W) (hW' : sideConsistent W')
    (hassert : W.assert = W'.assert)
    (hroots : ∀ i, W.parent i = none ↔ W'.parent i = none) :
    F W = F W' := by
  sorry -- both sides rewrite via side_locality to the same filter set

/-- Theorem 2: duplicating a claim (new child of c, same assertion) fixes F.
    Stated over an embedding of World n into World (n+1). -/
-- theorem copy_invariant ... (statement in repo; elided in sandbox draft)

/-- Theorem 3: majority voting is NOT copy invariant (explicit witness). -/
theorem majority_not_copyInvariant :
    ∃ (v : List Bool) (dup : List Bool),
      (v.count true > v.count false) ∧
      (dup.count false > dup.count true) ∧
      dup = v ++ [false, false] := by
  exact ⟨[true, true, false], [true, true, false, false, false],
         by decide, by decide, rfl⟩
