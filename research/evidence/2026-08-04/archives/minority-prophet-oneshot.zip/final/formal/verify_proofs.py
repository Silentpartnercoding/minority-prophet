"""Machine-led inspection: exhaustively verify Theorems 1-3 on ALL small
worlds, then 100k randomized larger instances. Exit nonzero on any violation."""
import itertools, random, sys

def roots_map(n, parent):
    r = {}
    def root(i):
        if i in r: return r[i]
        r[i] = i if parent[i] is None else root(parent[i])
        return r[i]
    return [root(i) for i in range(n)]

def verdict(n, parent, assert_):
    rm = roots_map(n, parent)
    s = {0: set(), 1: set()}
    for i in range(n):
        s[assert_[i]].add(rm[i])
    d = len(s[1]) - len(s[0])
    return 1 if d > 0 else 0 if d < 0 else None

def exhaustive(max_n=6):
    worlds = viol = rewirings = 0
    for n in range(1, max_n + 1):
        for assert_ in itertools.product((0, 1), repeat=n):
            # side-consistent parents: earlier index, same assertion, or root
            opts = [[None] + [j for j in range(i) if assert_[j] == assert_[i]]
                    for i in range(n)]
            for parent in itertools.product(*opts):
                worlds += 1
                v0 = verdict(n, parent, assert_)
                # Theorem 2: duplicate every claim
                for c in range(n):
                    p2 = list(parent) + [c]
                    a2 = list(assert_) + [assert_[c]]
                    if verdict(n + 1, p2, a2) != v0:
                        viol += 1
                # Theorem 1: ALL side-preserving rewirings of non-root edges
                ropts = [[parent[i]] if parent[i] is None else
                         [j for j in range(i) if assert_[j] == assert_[i]]
                         for i in range(n)]
                total = 1
                for o in ropts: total *= len(o)
                if total > 400:  # cap explosion; sample instead
                    rng = random.Random(worlds)
                    combos = ([tuple(rng.choice(o) for o in ropts)
                               for _ in range(400)])
                else:
                    combos = itertools.product(*ropts)
                for pw in combos:
                    rewirings += 1
                    if verdict(n, list(pw), assert_) != v0:
                        viol += 1
    return worlds, rewirings, viol

def randomized(trials=100_000, seed=7):
    rng, viol = random.Random(seed), 0
    for _ in range(trials):
        n = rng.randint(7, 40)
        assert_ = [rng.randint(0, 1) for _ in range(n)]
        parent = [None if rng.random() < 0.25 else
                  (rng.choice([j for j in range(i) if assert_[j] == assert_[i]])
                   if any(assert_[j] == assert_[i] for j in range(i)) else None)
                  for i in range(n)]
        v0 = verdict(n, parent, assert_)
        pw = [p if p is None else
              rng.choice([j for j in range(i) if assert_[j] == assert_[i]])
              for i, p in enumerate(parent)]
        if verdict(n, pw, assert_) != v0: viol += 1
        c = rng.randrange(n)
        if verdict(n + 1, parent + [c], assert_ + [assert_[c]]) != v0: viol += 1
    return viol

if __name__ == "__main__":
    w, rw, v1 = exhaustive()
    print(f"[exhaustive] worlds={w} rewirings_checked={rw} violations={v1}")
    v2 = randomized()
    print(f"[randomized] trials=100000 violations={v2}")
    # Theorem 3 counterexample check (majority NOT invariant)
    maj = lambda a: 1 if sum(a) * 2 > len(a) else 0 if sum(a) * 2 < len(a) else None
    t3 = maj([1, 1, 0]) == 1 and maj([1, 1, 0, 0, 0]) == 0
    print(f"[theorem3] majority flipped by duplication: {t3}")
    ok = v1 == 0 and v2 == 0 and t3
    print("VERDICT:", "ALL PROOF OBLIGATIONS PASS" if ok else "VIOLATIONS FOUND")
    sys.exit(0 if ok else 1)
